#!/bin/bash
echo "Code BeforeInstall event script ran."