#!/bin/bash
echo "Code ApplicationStart event script ran."