#!/bin/bash
echo "Code ValidateService event script ran."