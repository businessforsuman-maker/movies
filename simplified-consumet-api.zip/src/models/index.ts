import { IBookProviderParams, LibgenBook } from './types';

export { IBookProviderParams, LibgenBook };
